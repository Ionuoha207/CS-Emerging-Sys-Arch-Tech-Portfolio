/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// Global variables
static int setPoint = 25;
static int currentTemperature = 0;
static volatile unsigned long seconds = 0;
static volatile bool updateFlag = false;
static UART_Handle uart;

// Timer flag
volatile unsigned char TimerFlag = 0;

// Task period counters
unsigned long Task1Counter = 0;
unsigned long Task2Counter = 0;
unsigned long Task3Counter = 0;

// Function Prototypes
void initGPIO(void);
void initI2C(void);
void initUART(void);
void initTimer(void);
int16_t readTemp(void);
void updateLED(void);
void sendDataUART(void);
void gpioButtonFxn0(uint_least8_t index);
void gpioButtonFxn1(uint_least8_t index);
void timerCallback(Timer_Handle myHandle, int_fast16_t status);

// Initialize GPIO
void initGPIO(void) {
    GPIO_init();
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
}

// Initialize I2C
void initI2C(void) {
    I2C_Params i2cParams;
    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    I2C_Handle i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        while (1);
    }
}

// Initialize UART
void initUART(void) {
    UART_Params uartParams;
    UART_init();
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;
    uart = UART_open(CONFIG_UART_0, &uartParams);
    if (uart == NULL) {
        while (1);
    }
}

// Initialize Timer
void initTimer(void) {
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 200000; // 200 ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    Timer_Handle timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        while (1);
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        while (1);
    }
}

// Read Temperature
int16_t readTemp(void) {
    static const struct {
        uint8_t address;
        uint8_t resultReg;
        char *id;
    } sensors[3] = {
        { 0x48, 0x0000, "11X" },
        { 0x49, 0x0000, "116" },
        { 0x41, 0x0001, "006" }
    };
    uint8_t txBuffer[1];
    uint8_t rxBuffer[2];
    I2C_Transaction i2cTransaction;
    I2C_Handle i2c;
    I2C_Params i2cParams;
    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        while (1);
    }
    int8_t i, found = false;
    for (i = 0; i < 3; ++i) {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        i2cTransaction.writeBuf = txBuffer;
        i2cTransaction.writeCount = 1;
        i2cTransaction.readBuf = rxBuffer;
        i2cTransaction.readCount = 0;
        if (I2C_transfer(i2c, &i2cTransaction)) {
            found = true;
            break;
        }
    }
    if (found) {
        i2cTransaction.readCount = 2;
        if (I2C_transfer(i2c, &i2cTransaction)) {
            int16_t temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
            temperature *= 0.0078125;
            if (rxBuffer[0] & 0x80) {
                temperature |= 0xF000;
            }
            return temperature;
        }
    }
    return 0;
}

// Update LED based on temperature comparison
void updateLED(void) {
    if (currentTemperature < setPoint) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    }
}

// Send data to UART
void sendDataUART(void) {
    char output[64];
    snprintf(output, sizeof(output), "<%02d,%02d,%d,%04lu>", currentTemperature, setPoint, GPIO_read(CONFIG_GPIO_LED_0), seconds);
    UART_write(uart, output, strlen(output));
}

// Button interrupt handlers
void gpioButtonFxn0(uint_least8_t index) {
    setPoint++;
}

void gpioButtonFxn1(uint_least8_t index) {
    setPoint--;
}

// Timer callback
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1;
}

// Main thread
void *mainThread(void *arg0) {
    initGPIO();
    initUART();
    initI2C();
    initTimer();

    while (1) {
        if (TimerFlag) {
            TimerFlag = 0;
            Task1Counter++;
            Task2Counter++;
            Task3Counter++;

            if (Task1Counter >= 1) {
                Task1Counter = 0;
            }

            if (Task2Counter >= 2) {
                Task2Counter = 0;
                currentTemperature = readTemp();
            }

            if (Task3Counter >= 5) {
                Task3Counter = 0;
                updateLED();
                sendDataUART();
                seconds++;
            }
        }
    }
}
